package com.Segnalazioni.Segnalazioni;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SegnalazioniApplicationTests {

	@Test
	void contextLoads() {
	}

}
