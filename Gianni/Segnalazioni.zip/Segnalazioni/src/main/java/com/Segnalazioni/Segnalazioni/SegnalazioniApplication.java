package com.Segnalazioni.Segnalazioni;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SegnalazioniApplication {

	public static void main(String[] args) {
		SpringApplication.run(SegnalazioniApplication.class, args);
	}

}
